Thanks to HTML5's Canvas element, we were able to create an implementation of turtle programming in pure JavaScript, using only jQuery for readability.
Now with improved UI including the ability to move forward and backward in the interactive command box, turtle programming in JavaScript is easy enough for beginners and modifiable by advanced users thanks to its open-source nature.
You can access this live at: http://htmlpreview.github.io/?https://github.com/bjpop/js-turtle/blob/master/turtle.html
